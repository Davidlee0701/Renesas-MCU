# RH850 U2Bx FreeRTOS Community Supported Demo

## Introduction
This directory contains demo project for Renesas RH850 U2B10

This example implements the standard test demos detailed in following link: [RTOS Third Party Demo](https://github.com/FreeRTOS/FreeRTOS/blob/main/FreeRTOS/Demo/ThirdParty/Template/README.md)

## Note
The test case for `configSTART_INTERRUPT_QUEUE_TESTS` is out of scope.