/*===============================================================================================

    Copyright (c) 2013 by Renesas Electronics Europe GmbH, a company of the Renesas Electronics
    Corporation. All rights reserved.

  ===============================================================================================

    Warranty Disclaimer

    Because the Product(s) is licensed free of charge, there is no warranty of any kind
    whatsoever and expressly disclaimed and excluded by Renesas, either expressed or implied,
    including but not limited to those for non-infringement of intellectual property,
    merchantability and/or fitness for the particular purpose.
    Renesas shall not have any obligation to maintain, service or provide bug fixes for the
    supplied Product(s) and/or the Application.

    Each User is solely responsible for determining the appropriateness of using the Product(s)
    and assumes all risks associated with its exercise of rights under this Agreement, including,
    but not limited to the risks and costs of program errors, compliance with applicable laws,
    damage to or loss of data, programs or equipment, and unavailability or interruption of
    operations.

    Limitation of Liability

    In no event shall Renesas be liable to the User for any incidental, consequential, indirect,
    or punitive damage (including but not limited to lost profits) regardless of whether such
    liability is based on breach of contract, tort, strict liability, breach of warranties,
    failure of essential purpose or otherwise and even if advised of the possibility of such
    damages. Renesas shall not be liable for any services or products provided by third party
    vendors, developers or consultants identified or referred to the User by Renesas in
    connection with the Product(s) and/or the Application.

  ===============================================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include "device.h"
#include "shared.h"
#include "gtm.h"

#define MIN_COUNT   (8000)

//#define CM0CNT 1666 // period = 1666* 6.25ns = 10.4 us = ~96kHz, T0_PWM is defined in gtm.h
//#define CM1CNT 50 // period = 50*6.25ns = ~312ns ~3.2MHz, T0_PWM is defined in gtm.h
// For 1 ms period on CLK3 = 6.25 ns (160 MHz): counts = 1ms / 6.25ns = 160000
#define CM0CNT 160000 // 1 ms period @ 6.25 ns (160 MHz)
#define CM1CNT 52 // secondary channel (unchanged)

__SHARED( extern T_STATE, statePE0)

int pe0Var1;
int pe0Var2;

static char *pTmp;

void R_InitClk(void)
{
    SYSCTRLCLKKCPROT1= 0xA5A5A501;
    asm("syncp");
    SYSCTRLCKSC_CPUC= 0;
    SYSCTRLPLLCLKDCSID= 1;

    /* Start MOSC and PLL (if option byte 11 STARTUPPLL bit is set to 0) */
    SYSCTRLMOSCENTRG= 1; while(SYSCTRLMOSCEN!=0x1);
    while(SYSCTRLMOSCSTAB!=0x1);
    SYSCTRLPLLENTRG= 1; while(SYSCTRLPLLCLKEN!=0x1);
    while(SYSCTRLPLLCLKSTAB!=0x1);
    asm("syncp");
    SYSCTRLCLKKCPROT1= 0xA5A5A500;

	SYSCTRLMSRKCPROT    = 0xA5A5A501;// enable writing to MCR_ registers
	SYSCTRLMSR_GTM  = 0x00000000;// enable GTM clock
	SYSCTRLMSRKCPROT    = 0xA5A5A500;// disable writing to MCR_ registers	
}

/*===========================================================================
    Port Configuration
    GTMAT0O0  P6_3 
  ===========================================================================*/
void R_GTM_ATOM_Tick_CfgPort(void)

{
	PORT0PKCPROT = 0xA5A5A501;
    PORT0PWE = 0x0FFFFFFE;
	PORT0PMC6    |=  ((1<<3));// alternative function mode - AF 1 GTMAT0O0
    PORT0PFCAE6  &= ~((1<<3));// PFCAE=0
    PORT0PFCE6   &= ~((1<<3));// PFCE=0
    PORT0PFC6    &= ~((1<<3));// PFC=0
    PORT0PM6     &= ~((1<<3));// output	

	PORT0PMC6    |=  ((1<<11));// alternative function mode - AF 1 GTMAT0O1
    PORT0PFCAE6  &= ~((1<<11));// PFCAE=0
    PORT0PFCE6   &= ~((1<<11));// PFCE=0
    PORT0PFC6    &= ~((1<<11));// PFC=0
    PORT0PM6     &= ~((1<<11));// output	

	PORT0PKCPROT = 0xA5A5A500;
}


/*===========================================================================
    GTM Configuration

  ===========================================================================*/
void R_GTM_ATOM_Tick_application(void)
{
        unsigned long status = 0;

        //printf ("Configure CCM for cluster 0\n");
        GTM0GTM_CTRL       = 0x00000000;// RF_PROT=0
        GTM0CLS0_CLK_DIV   = 1;// 1:1 clock (160MHz)
        GTM0CCM0_PROT      = 0x00000000;// write protection of CCM regs disabled
        GTM0CCM0_CFG       = 0x0000000F;// enable clock to MCS, ATOM, ADTM, TOM, TDTM, TIM
        status = GTM0CCM0_CFG;
        if ((status&0x00030000) != 0x00010000) {
                printf("ERROR: Cluster 0 does not run will 1:1 clk \n");
                while(1);// Stay here if not full speed
        }

        //printf ("Configure CMU\n");
        GTM0CMU_GCLK_NUM   = 0x0000FFFF;// global divider = *1
        GTM0CMU_GCLK_DEN   = 0x0000FFFF;
        //GTM0CMU_CLK_3_CTRL = 0x00000003;// sys_clk_period * 4 = 25ns (40MHz) @ 160MHz sys_clk
        GTM0CMU_CLK_3_CTRL = 0x00000000; // sys_clk_period = 6.25 ns 160MHz
        GTM0CMU_CLK_EN     = 0x00000080;// enable CMU clock 3
        status = GTM0CMU_CLK_EN;
        if (status != 0x000000C0) {
                printf("ERROR: CMU clock 3 cannot be enabled\n");
                while(1);// Stay here if clock could not be enabled
        }

        /* In any output mode, if a channel is enabled, one-shot mode is disabled (OSM = 0; only used
         * in modes SOMP and SOMS) and CM0 ≥ CN0, the counter CN0 is incrementing until it
         * reaches CM0. To avoid unintended counting of CN0 after enabling a channel, it is
         * recommended to reset a channel (or at least CN0 and CM0) before any change on the mode
         * bits MODE, ARU_EN and OSM. */

        GTM0ATOM0_AGC_GLB_CTRL = 0x300;
        GTM0ATOM0_CH0_CM0 = 0;
        GTM0ATOM0_CH0_CN0 = 0;

        GTM0ATOM0_CH1_CM0 = 0;
        GTM0ATOM0_CH1_CN0 = 0; 

        // up count mode, 20kHz cm0 and cm1 can be used to control rise/fall edge inside of period of CH0
        GTM0ATOM0_CH0_CTRL = 0x2 + (0<<3) + (0<<11) + (3<<12) + (0<<20) + (1<<24);// SOMP, ARU off, SL=LO, CLK3, reset on CN0=CM0, trigout ccu0
                                                                                  // up count mode, 20kHz cm0 and cm1 can be used to control rise/fall edge inside of period of CH0
        GTM0ATOM0_CH1_CTRL = 0x2 + (0<<3) + (0<<11) + (3<<12) + (0<<20) + (1<<24);// SOMP, ARU off, SL=LO, CLK3, reset on CN0=CM0, trigout ccu0

        // initial values for ATOM0 channel 0:
        //    GTM0ATOM0_CH0_CM0 = 26;// period = 26* 6.25ns = 156.25ns , T0_PWM is defined in gtm.h
        //    GTM0ATOM0_CH0_CM1 = 26/2;// duty cycle


        GTM0ATOM0_CH0_CM0 = CM0CNT;//     
        GTM0ATOM0_CH0_CM1 = CM0CNT/2;// duty cycle

        GTM0ATOM0_CH0_CN0 = CM0CNT-1;// initial delay = 0
        GTM0ATOM0_CH0_SR0 = CM0CNT;// same values also in shadow registers
        GTM0ATOM0_CH0_SR1 = CM0CNT/2;

        GTM0ATOM0_CH0_IRQ_EN     = 0x00000001;// enable interrupt CCU0 of ATOM0_CH0
        GTM0ATOM0_AGC_INT_TRIG   = 0x00000002;// int. trig channel 0

        // initial values for ATOM0 channel 0:
        //GTM0ATOM0_CH1_CM0 = 52;// period = 52*6.25ns = 325ns, T0_PWM is defined in gtm.h
        //GTM0ATOM0_CH1_CM1 = 52/2;// duty cycle

        GTM0ATOM0_CH1_CM0 = CM1CNT;
        GTM0ATOM0_CH1_CM1 = CM1CNT/2;// duty cycle

        GTM0ATOM0_CH1_CN0 = CM1CNT-1;// initial delay = 0
        GTM0ATOM0_CH1_SR0 = CM1CNT;// same values also in shadow registers
        GTM0ATOM0_CH1_SR1 = CM1CNT/2;

        //GTM0ATOM0_CH1_IRQ_EN     = 0x00000001;// enable interrupt CCU0 of ATOM0_CH1

        //GTM0ATOM0_AGC_INT_TRIG = 0x00000002;// int. trig channel 0
        //GTM0ATOM0_AGC_INT_TRIG = 0x0000000a;// int. trig channel 0

        //GTM0ATOM0_AGC_GLB_CTRL = 0x00020000;// enable update from SR regs of ch 0
        GTM0ATOM0_AGC_GLB_CTRL = 0x000a0000;// enable update from SR regs of ch 0,1
                                            // GTM0ATOM0_AGC_OUTEN_CTRL = 0x00000002;// enable output 0
        GTM0ATOM0_AGC_OUTEN_CTRL = 0x0000000a;// enable output 0,1 


        //   GTM0ATOM0_AGC_ENDIS_CTRL = 0x00000002;// enable channel 0 on update trigger
        GTM0ATOM0_AGC_ENDIS_CTRL = 0x0000000a;// enable channel 0,1 on update trigger

        //   GTM0ATOM0_AGC_FUPD_CTRL  = 0x00020002;// force update on ch 0
        //   GTM0ATOM0_AGC_FUPD_CTRL  = 0x0005000a;// force update on ch 0, 1

        //GTM0ATOM0_AGC_GLB_CTRL  |= 0x00000001;// host trigger for start of ATOM0
        GTM0ATOM0_AGC_GLB_CTRL  |= 0x00000001;// host trigger for start of ATOM00, ATOM01

        // after enable by host trigger set force update flags for next internal trigger
        //GTM0ATOM0_AGC_FUPD_CTRL  = 0x80A980A9;// reset CN0 on FUPD, force update on ch 1 to 3 and 7
}

/*===========================================================================
    GTM ATOM0 Shared interrupts (ATOM0_IRQ0)

  ===========================================================================*/
__interrupt void EIINT143(void)// ATOM0 Shared interrupts (ATOM0_IRQ0)
{
    // Clear GTM ATOM0 CH0 interrupt notify flag so it can fire again
    GTM0ATOM0_CH0_IRQ_NOTIFY = 0x00000001;
    // small debug nop (you can set a breakpoint here)
    __asm("nop");
}

/*===========================================================================
    MAIN

  ===========================================================================*/
int main(int argc, char *argv[])
{
        int     __thisPE   = 1<<GetPEID();
        unsigned int     __thisPEID;

        __thisPEID= __SCH1R( __thisPE) -1;

        R_InitClk();
        initSharedMemory( __thisPEID);
        /* Wait for PE1 beeing ready at main() */
        while( GetState( PE1) != PE1_RDY)
                __SNOOZE();

        ThreadLocked= 2;
        statePE0= PE0_RDY;

        pTmp= (char *)malloc( 60);
        init( 0xdeadc0de);
        ThreadLocked= 0;    /* Unlock all cores */
        if( pTmp != NULL)
                initV( (int *)pTmp, 0xdeadc0de);
        printf("Hello world from PE%d.\n", __thisPEID);
        statePE0= PE0_RUN;

        DelayMS( 500);  /* wait for 500 ms */

        /* if PE1 is finished, start over ... */
        //swreset0(100);

        __DI();
        INTC2EIC143 = 0x40;// enable ATOM0 Shared interrupts (ATOM0_IRQ0) in INTC2, refer to Interrupt_table.xls in User's Manual
        R_GTM_ATOM_Tick_CfgPort();
        R_GTM_ATOM_Tick_application();

        __EI();

        while(1)
                __SNOOZE();
}
