In this basic example GTM's ATOM0 channel 0 is used as a tick timer. A tick of 1ms triggers ATOM0 interrupt. (+ISR)
