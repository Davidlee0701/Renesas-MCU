/*===============================================================================================

    Copyright (c) 2013 by Renesas Electronics Europe GmbH, a company of the Renesas Electronics 
    Corporation. All rights reserved.

  ===============================================================================================

    Warranty Disclaimer                                                       
                                                                             
    Because the Product(s) is licensed free of charge, there is no warranty of any kind
    whatsoever and expressly disclaimed and excluded by Renesas, either expressed or implied, 
    including but not limited to those for non-infringement of intellectual property, 
    merchantability and/or fitness for the particular purpose.
    Renesas shall not have any obligation to maintain, service or provide bug fixes for the
    supplied Product(s) and/or the Application.

    Each User is solely responsible for determining the appropriateness of using the Product(s)
    and assumes all risks associated with its exercise of rights under this Agreement, including,
    but not limited to the risks and costs of program errors, compliance with applicable laws,
    damage to or loss of data, programs or equipment, and unavailability or interruption of
    operations.

    Limitation of Liability

    In no event shall Renesas be liable to the User for any incidental, consequential, indirect,
    or punitive damage (including but not limited to lost profits) regardless of whether such
    liability is based on breach of contract, tort, strict liability, breach of warranties, 
    failure of essential purpose or otherwise and even if advised of the possibility of such
    damages. Renesas shall not be liable for any services or products provided by third party
    vendors, developers or consultants identified or referred to the User by Renesas in 
    connection with the Product(s) and/or the Application.

  ===============================================================================================*/

/*
 * This module initializes some variables, which are defined
 * in both cores as well as in shared.
 * But PE0 cannot access PE1 local RAM and vice versa, so that
 * core variables are not accessed! Before doing so, guard access
 * has to be deactivated, which is not done in this sample.
 * That means:
 * PE0 comes here:
 *  access global memory:      OK
 *  access PE0 local memory:   OK
 *  access PE1 local memory:   NG
 * PE1 comes here:
 *  access global memory:      OK
 *  access PE0 local memory:   NG
 *  access PE1 local memory:   OK
 *
 */

#include <stdio.h>
#include <device.h>
#include "shared.h"

#define MIN_COUNT   (8000)

__SHARED( T_STATE, statePE0)
__SHARED( T_STATE, statePE1)
#ifdef PE2
__SHARED( T_STATE, statePE2)
#endif            
#ifdef PE3
__SHARED( T_STATE, statePE3)
#endif            
#ifdef PE4
__SHARED( T_STATE, statePE4)
#endif            
#ifdef PE5
__SHARED( T_STATE, statePE5)
#endif            

extern int pe0Var1;
extern int pe0Var2;
extern int pe1Var1;
extern int pe1Var2;
#ifdef PE2
extern int pe2Var1;
extern int pe2Var2;
#endif            
#ifdef PE3
extern int pe3Var1;
extern int pe3Var2;
#endif            
#ifdef PE4
extern int pe4Var1;
extern int pe4Var2;
#endif            
#ifdef PE5
extern int pe5Var1;
extern int pe5Var2;
#endif            
 
void mysharedfunc(void);

extern volatile unsigned long countloop=MIN_COUNT;     /* Is modified by connected emulator */
static unsigned int s_id=1;

void initSharedMemory( unsigned int __thisPEID)
{
    if( countloop==0)
        countloop= 8192;
    printf( "Hello world from SHARED space (called by PE%d), version %d.\n",
            __thisPEID, s_id);
}

void init( int value)
{
    pe0Var1 = 1;    /* Default: Can only be accessed by PE0 */
    pe1Var1 = 1;    /* Default: Can only be accessed by PE1 */
    pe0Var2 = value;
    mysharedfunc();
}

void initV( int *pa, int value)
{
    *pa = (int )value;
    mysharedfunc();
}

T_STATE GetState( int pe)
{
    T_STATE state= PE_FAIL;
    switch( pe) 
    {
        case PE0:
            state= statePE0;
            break;
        case PE1:
            state= statePE1;
            break;
#ifdef PE2
        case PE2:
            state= statePE2;
            break;
#endif            
#ifdef PE3
        case PE3:
            state= statePE3;
            break;
#endif            
#ifdef PE4
        case PE4:
            state= statePE4;
            break;
#endif            
#ifdef PE5
        case PE5:
            state= statePE5;
            break;
#endif
        default: 
            state= PE_UNDEF;
    }
    return state;
}


/* Spend a longer time in the loop of ms
 * DELAYBOUND is defined in device.h
 * snooze is configured for 32 clock cycles
 * approx. 1 millisecond running at 400 MHz ~ DELAYBOUND_400
 * approx. 1 millisecond running at 200 MHz ~ DELAYBOUND_200
 * approx. 1 millisecond running at 080 MHz ~ DELAYBOUND_080
 * approx. 1 millisecond running at 160 MHz ~ DELAYBOUND_160
 * approx. 1 millisecond running at 240 MHz ~ DELAYBOUND_240
 * approx. 1 millisecond running at 320 MHz ~ DELAYBOUND_320
 */

void DelayMS( unsigned long cnt)
{
    if( cnt==0) cnt=1;  /* Make sure, 0 is changed to 1 */
    cnt= DELAYBOUND * cnt;
    do {
        __SNOOZE();
    } while( --cnt>0);

}

