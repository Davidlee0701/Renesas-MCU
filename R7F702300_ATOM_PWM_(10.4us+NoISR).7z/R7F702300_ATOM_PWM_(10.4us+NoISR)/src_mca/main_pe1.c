/*===============================================================================================

    Copyright (c) 2013 by Renesas Electronics Europe GmbH, a company of the Renesas Electronics 
    Corporation. All rights reserved.

  ===============================================================================================

    Warranty Disclaimer                                                       
                                                                             
    Because the Product(s) is licensed free of charge, there is no warranty of any kind
    whatsoever and expressly disclaimed and excluded by Renesas, either expressed or implied, 
    including but not limited to those for non-infringement of intellectual property, 
    merchantability and/or fitness for the particular purpose.
    Renesas shall not have any obligation to maintain, service or provide bug fixes for the
    supplied Product(s) and/or the Application.

    Each User is solely responsible for determining the appropriateness of using the Product(s)
    and assumes all risks associated with its exercise of rights under this Agreement, including,
    but not limited to the risks and costs of program errors, compliance with applicable laws,
    damage to or loss of data, programs or equipment, and unavailability or interruption of
    operations.

    Limitation of Liability

    In no event shall Renesas be liable to the User for any incidental, consequential, indirect,
    or punitive damage (including but not limited to lost profits) regardless of whether such
    liability is based on breach of contract, tort, strict liability, breach of warranties, 
    failure of essential purpose or otherwise and even if advised of the possibility of such
    damages. Renesas shall not be liable for any services or products provided by third party
    vendors, developers or consultants identified or referred to the User by Renesas in 
    connection with the Product(s) and/or the Application.

  ===============================================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include "device.h"
#include "shared.h"


__SHARED( extern T_STATE, statePE1)

int pe1Var1;
int pe1Var2;


static char *pTmp;

int main(int argc, char *argv[])
{
    int     __thisPE   = 1<<GetPEID();
    unsigned int     __thisPEID;

    __thisPEID= __SCH1R( __thisPE) -1;

    statePE1= PE1_RDY;
    pTmp= (char *)malloc( 60);
    do {
        __SNOOZE();
    } while( ThreadLocked == 2);

    init( 0xdeadbeef);      /* using PE0 variables */

    if( pTmp != NULL)
        initV( (int *)pTmp, 0xdeadbeef);

    printf("Hello world from PE%d.\n", __thisPEID);
    
    /* Spend a longer time, before inidcating we are ready to run */
    /* approx. 1 second running at 240 MHz */
    DelayMS( 1000);

    /* read to Run */
    statePE1 = PE1_RUN;
    
    while(1)
        __SNOOZE();
}
