In this basic example GTM's ATOM0 channel 0 is used as a tick timer. A tick of 10.4us triggers ATOM0 interrupt.

-> (10.4us+NoISR)
